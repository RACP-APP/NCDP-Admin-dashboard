import React from 'react';
import $ from 'jquery';
import config from '../config';

class TopHeader extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div className="Mainheader "> </div>;
  }
}

export default TopHeader;
