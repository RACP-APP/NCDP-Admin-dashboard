var config = {
  apiKey: 'AIzaSyAFSTEpX_9R0pzLQ36zBFYxKs19hjxKytA',
  authDomain: 'ncdp-270519.firebaseapp.com',
  databaseURL: 'https://ncdp-270519.firebaseio.com',
  projectId: 'ncdp-270519',
  storageBucket: 'ncdp-270519.appspot.com',
  messagingSenderId: '494635556973',
  appId: '1:494635556973:web:1baf74fc1b51eda1885f64',
  measurementId: 'G-HLNN3MLT5V',
  type: 'service_account',
  project_id: 'ncdp-270519',
  private_key_id: '7245f3e959cd2cceaff72894bf143898796f36c2',
  private_key:
    '-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDk7UR0U0CNU/IR\nBtQsG+fUYaorwxjoZwQ/IZiJb0edM6SOwZq6RZf4Jjy8/4f1IJQdXAO5hsZZveLN\n1fY2hh9CK2oRfz8xb1CN8lnk3JIMt4tN5W5TODW3QUBvZomIDhsiSdeoIhMjvy+Y\ntD8PCFuSGOiqQBww3s85N+ubXfalN10HlPc4C3ZvMhglk24vJYeUUdpXHJFSBPcp\n10C+mha2INDWS2noQEhXWNOg2ynjdoMt+RJfu5IjMttStmR4kB/sJkTAvHlipLOy\nA1+qpFNCNN7ENXOjoJ2BukrdPPBNPxlajTJZ0Elrj4f4LLUX2pOY/85fJ0mhp2h4\nfP0fedO5AgMBAAECggEAA8vhgj0CiYrLrWJGcNLSUJCBZhy5VC/9Kd+F7Drhs6bb\nGEOirBXNCYr3dTpBnXGPCJZG44lAzyqEe922qbx7Vo6/bA8xqOwL0xwinIEslN8T\nBYAus7JExcdkaP8zfFj2NJEyl9xfd+IgSRvYHd40HTiiMcyYCxbEK1KU6tcvPhnP\nEwbD1Hp+fs5sTmjJKWvNHkVhYuvNB/JchapPyAO31BYhSI6JlFfKF6eiPGf42AmI\nQxyBqAbA2/YmBuRBH+2ZSk8dT/Y8ZwwHBh8L4fQ70hhEstrsUMNEGXrafInLz7PS\n/X7mifq/s3rATuK/FSNRLPjqf9O9BshR5tzxHzre9wKBgQD6IVFH66K2n/t51zCG\ngh4N/HGJ5OkA5f3PexHb3eAWe9ZHEoJsYNzLT2PvIhtI1ocFoPvPuftylkr+dpxI\nHClmXuLGoSh1klc32Edutv1h6KwDDvUkasX5Rrc9Yebs96x4m0U9KyIWuGABl2Vb\n5evSBGav5c0G20NRkaUkFwVgWwKBgQDqTJGbJCIDTSHdHm5P72IwwMh8qGlbzCgF\nZ4ShnH8mtQVRbNUCqRpJse3F+4BDCSgbr79n0RzCYV3z7xNk07tGHctBuhXfUNlh\nv5Jn0wBixEFrIHmL3u8+uwDctblo7wntG1O6FqBMKemUC/gTJasoroaioxEeata3\n0Mcgo1QYewKBgBruG2Iy7IHdF6Y2lPLmb3XyCAdgrfV6zajZB0M00DubeaaNR52D\nkEITeh70/RsKfd8NRg9HZtsfc1OSUaEx5wMulBvunfyKlPleP9KbwQwZkOuDYMFa\n/ZWpF3F0aPh6cgdKMFo1mqX3k96X/kG2r30dHDEz/K8QTF8r3yvTjrChAoGBAJgW\nPcnz6XQ1JE8xSq/ultFIwptQgpuI6U2gxZJWUJ8ikCIrwBVrCVpe+hYyzC43imZ2\nbYuJTN7Mbz1BqlgfrIe2HVM75KjCBWmS/gkRCUYTWNeeC+gEPU59+vBJseHwkIPt\n4iqAN2tZJXrpTg23vOO6bkCyExGojlphVnDUNGlzAoGAUkqDxQDQyN8chcFcl4AI\nWoj0RV7nFxy9loggo2FkNAuPhccZJPkUXOcuAx1r8vZ6nzyPxfD13dJxPjNu7IZk\n72SMdnp2R8vITMJJaeuqE5VCdh/9yfBQZnAtO0NsBLWJkDCARu1zesu+9DUCQ69a\nTUMoLunCcHjOQcSWfVeJmho=\n-----END PRIVATE KEY-----\n',
  client_email: 'firebase-adminsdk-7vzkv@ncdp-270519.iam.gserviceaccount.com',
  client_id: '105451979322097880921',
  auth_uri: 'https://accounts.google.com/o/oauth2/auth',
  token_uri: 'https://oauth2.googleapis.com/token',
  auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
  client_x509_cert_url:
    'https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-7vzkv%40ncdp-270519.iam.gserviceaccount.com'
};

// firebase.initializeApp(config);
export default config;
